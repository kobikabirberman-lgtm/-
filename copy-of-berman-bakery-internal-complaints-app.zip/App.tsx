
import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import ComplaintForm from './components/ComplaintForm';
import ComplaintList from './components/ComplaintList';
import Stats from './components/Stats';
import { Complaint } from './types';

const App: React.FC = () => {
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [view, setView] = useState<'form' | 'history' | 'stats'>('form');
  const [cloudUrl, setCloudUrl] = useState<string>(localStorage.getItem('berman_cloud_url') || '');
  const [isSyncing, setIsSyncing] = useState(false);

  // Load from local storage on mount
  useEffect(() => {
    const saved = localStorage.getItem('berman_complaints');
    if (saved) {
      setComplaints(JSON.parse(saved));
    }
  }, []);

  // Save to local storage on change
  useEffect(() => {
    localStorage.setItem('berman_complaints', JSON.stringify(complaints));
  }, [complaints]);

  const syncToCloud = useCallback(async (complaint: Complaint) => {
    if (!cloudUrl) return;
    
    try {
      await fetch(cloudUrl, {
        method: 'POST',
        mode: 'no-cors',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(complaint)
      });
      return true;
    } catch (err) {
      console.error('Cloud sync failed:', err);
      return false;
    }
  }, [cloudUrl]);

  const handleSyncAll = async () => {
    if (!cloudUrl || complaints.length === 0) return;
    setIsSyncing(true);
    let successCount = 0;
    
    // סנכרון אחד אחד כדי לא להעמיס על ה-Script של גוגל
    for (const complaint of complaints) {
      const success = await syncToCloud(complaint);
      if (success) successCount++;
    }
    
    setIsSyncing(false);
    alert(`הסנכרון הסתיים! ${successCount} תלונות נשלחו לטבלה.`);
  };

  const handleAddComplaint = (newComplaint: Complaint) => {
    setComplaints(prev => {
      if (prev.find(c => c.id === newComplaint.id)) return prev;
      return [newComplaint, ...prev];
    });
    
    syncToCloud(newComplaint);
    setView('history');
  };

  const handleMergeComplaints = (importedComplaints: Complaint[]) => {
    setComplaints(prev => {
      const existingIds = new Set(prev.map(c => c.id));
      const newOnes = importedComplaints.filter(c => !existingIds.has(c.id));
      return [...newOnes, ...prev];
    });
  };

  const updateCloudUrl = (url: string) => {
    setCloudUrl(url);
    localStorage.setItem('berman_cloud_url', url);
  };

  const handleDelete = (id: string) => {
    if (window.confirm('האם אתה בטוח שברצונך למחוק תלונה זו מהמכשיר?')) {
      setComplaints(prev => prev.filter(c => c.id !== id));
    }
  };

  return (
    <div className="min-h-screen pb-12 bg-[#FAF7F2]">
      <Header setView={setView} currentView={view} />
      
      <main className="max-w-5xl mx-auto px-4 mt-8">
        {view === 'form' && (
          <div className="animate-fade-in">
            <div className="flex items-center justify-between mb-6">
               <h2 className="text-2xl font-bold text-amber-900 border-r-4 border-amber-600 pr-4">הוספת תלונה חדשה</h2>
               <div className="flex items-center gap-2">
                 <div className={`w-3 h-3 rounded-full ${cloudUrl ? 'bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]' : 'bg-gray-300'}`}></div>
                 <span className="text-xs text-amber-700 font-bold">{cloudUrl ? 'סנכרון ענן פעיל' : 'מצב מקומי בלבד'}</span>
               </div>
            </div>
            <ComplaintForm onAdd={handleAddComplaint} />
          </div>
        )}

        {view === 'history' && (
          <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-amber-900 mb-6 border-r-4 border-amber-600 pr-4">היסטוריית תלונות במכשיר זה</h2>
            <ComplaintList complaints={complaints} onDelete={handleDelete} />
          </div>
        )}

        {view === 'stats' && (
          <div className="animate-fade-in">
            <h2 className="text-2xl font-bold text-amber-900 mb-6 border-r-4 border-amber-600 pr-4">ניהול וסנכרון מרכזי</h2>
            <Stats 
              complaints={complaints} 
              onImport={handleMergeComplaints} 
              cloudUrl={cloudUrl} 
              onUpdateCloudUrl={updateCloudUrl}
              onSyncAll={handleSyncAll}
              isSyncing={isSyncing}
            />
          </div>
        )}
      </main>
    </div>
  );
};

export default App;
