
import { GoogleGenAI, Type } from "@google/genai";
import { Urgency } from "../types";

export const analyzeComplaint = async (description: string, productName: string, base64Image?: string) => {
  // Use the API key directly from the environment variable as per guidelines
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const parts: any[] = [
      { text: `Analyze this internal bakery complaint for Berman Bakery. 
      Product: ${productName}. 
      Complaint description: ${description}.
      ${base64Image ? "An image of the product is also provided. Please examine it for visible defects." : ""}
      Provide categorization, urgency, and a professional summary in Hebrew.` }
    ];

    if (base64Image) {
      const [header, data] = base64Image.split(',');
      const mimeType = header.match(/:(.*?);/)?.[1] || 'image/jpeg';
      parts.push({
        inlineData: {
          mimeType,
          data
        }
      });
    }

    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: { parts },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            category: { type: Type.STRING, description: "Category of the issue (e.g., Production, Packaging, Logistics)" },
            urgency: { type: Type.STRING, enum: [Urgency.LOW, Urgency.MEDIUM, Urgency.HIGH, Urgency.CRITICAL] },
            summary: { type: Type.STRING, description: "One sentence summary in Hebrew" },
            visualFindings: { type: Type.STRING, description: "If an image was provided, describe what is seen in Hebrew. Otherwise null." }
          },
          required: ["category", "urgency", "summary"]
        }
      }
    });

    return JSON.parse(response.text);
  } catch (error) {
    console.error("AI Analysis Error:", error);
    return {
      category: "כללי",
      urgency: Urgency.MEDIUM,
      summary: "ניתוח אוטומטי לא זמין"
    };
  }
};
