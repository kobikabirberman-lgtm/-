
import React from 'react';
import { Complaint, Urgency } from '../types';

interface ComplaintListProps {
  complaints: Complaint[];
  onDelete: (id: string) => void;
}

const getUrgencyColor = (urgency?: Urgency) => {
  switch (urgency) {
    case Urgency.CRITICAL: return 'bg-red-600 text-white';
    case Urgency.HIGH: return 'bg-orange-500 text-white';
    case Urgency.MEDIUM: return 'bg-amber-500 text-white';
    case Urgency.LOW: return 'bg-green-500 text-white';
    default: return 'bg-gray-400 text-white';
  }
};

const ComplaintList: React.FC<ComplaintListProps> = ({ complaints, onDelete }) => {
  if (complaints.length === 0) {
    return (
      <div className="text-center py-20 bg-white rounded-2xl border border-dashed border-amber-300">
        <svg className="mx-auto h-16 w-16 text-amber-200" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
        <p className="mt-4 text-amber-800 font-medium text-lg">אין תלונות רשומות עדיין</p>
        <p className="text-amber-600">כל תלונה שתגיש תופיע כאן לצרכי מעקב</p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 gap-6">
      {complaints.map(complaint => (
        <div key={complaint.id} className="bg-white rounded-2xl shadow-sm border border-amber-100 hover:shadow-md transition-shadow overflow-hidden group">
          <div className="flex flex-col md:flex-row">
            {complaint.image && (
              <div className="md:w-1/4 h-48 md:h-auto overflow-hidden bg-amber-50 border-l border-amber-100 flex items-center justify-center">
                <img src={complaint.image} alt={complaint.productName} className="w-full h-full object-cover" />
              </div>
            )}
            <div className={`p-6 flex-1 ${!complaint.image ? 'w-full' : ''}`}>
              <div className="flex flex-wrap justify-between items-start gap-4 mb-4">
                <div>
                  <h3 className="text-xl font-bold text-amber-900">{complaint.productName}</h3>
                  <div className="flex items-center gap-2 mt-1">
                    <span className="text-sm font-medium text-amber-600 bg-amber-50 px-2 py-0.5 rounded">קוד: {complaint.productCode}</span>
                    <span className="text-xs text-amber-500">{complaint.date}</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {complaint.aiAnalysis && (
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${getUrgencyColor(complaint.aiAnalysis.urgency)}`}>
                      {complaint.aiAnalysis.urgency}
                    </span>
                  )}
                  <button 
                    onClick={() => onDelete(complaint.id)}
                    className="p-2 text-red-400 hover:text-red-600 transition-colors opacity-0 group-hover:opacity-100"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
              </div>

              <p className="text-amber-800 bg-amber-50/50 p-3 rounded-lg border border-amber-50 mb-4 whitespace-pre-wrap text-sm md:text-base">
                {complaint.description}
              </p>

              {complaint.aiAnalysis && (
                <div className="space-y-2">
                  <div className="flex items-center gap-4 text-sm bg-amber-50/30 p-3 rounded-lg border border-amber-100">
                    <div className="flex items-center gap-1.5 font-bold text-amber-900 shrink-0">
                      <span className="w-2 h-2 rounded-full bg-amber-400"></span>
                      קטגוריה: {complaint.aiAnalysis.category}
                    </div>
                    <div className="text-amber-700 italic">
                      "{complaint.aiAnalysis.summary}"
                    </div>
                  </div>
                  {complaint.aiAnalysis.visualFindings && (
                    <div className="text-xs text-amber-600 px-3 flex items-center gap-2">
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" />
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" />
                      </svg>
                      <span>ממצא ויזואלי: {complaint.aiAnalysis.visualFindings}</span>
                    </div>
                  )}
                </div>
              )}
              
              <div className="mt-4 pt-4 border-t border-amber-50 flex justify-between items-center text-[10px] md:text-xs text-amber-500">
                <span>נשלח אל: {complaint.targetEmail}</span>
                <span>מאת: {complaint.reporterEmail}</span>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};

export default ComplaintList;
