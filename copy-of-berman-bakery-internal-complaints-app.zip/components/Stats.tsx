
import React, { useRef, useState } from 'react';
import { Complaint } from '../types';

interface StatsProps {
  complaints: Complaint[];
  onImport: (complaints: Complaint[]) => void;
  cloudUrl: string;
  onUpdateCloudUrl: (url: string) => void;
  onSyncAll: () => Promise<void>;
  isSyncing: boolean;
}

const Stats: React.FC<StatsProps> = ({ complaints, onImport, cloudUrl, onUpdateCloudUrl, onSyncAll, isSyncing }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [urlInput, setUrlInput] = useState(cloudUrl);
  const [activeTab, setActiveTab] = useState<'sync' | 'deploy' | 'tools'>('deploy');
  const [justConnected, setJustConnected] = useState(false);

  const handleConnect = () => {
    onUpdateCloudUrl(urlInput);
    setJustConnected(true);
    setTimeout(() => setJustConnected(false), 3000);
  };

  return (
    <div className="space-y-6">
      <div className="flex bg-amber-100/50 p-1 rounded-xl gap-1">
        <button 
          onClick={() => setActiveTab('sync')}
          className={`flex-1 py-2 px-4 rounded-lg font-bold text-sm transition-all ${activeTab === 'sync' ? 'bg-white text-amber-900 shadow-sm' : 'text-amber-700 hover:bg-amber-100'}`}
        >
          סנכרון ענן
        </button>
        <button 
          onClick={() => setActiveTab('deploy')}
          className={`flex-1 py-2 px-4 rounded-lg font-bold text-sm transition-all ${activeTab === 'deploy' ? 'bg-white text-amber-900 shadow-sm' : 'text-amber-700 hover:bg-amber-100'}`}
        >
          איך מעלים קבצים? 📤
        </button>
        <button 
          onClick={() => setActiveTab('tools')}
          className={`flex-1 py-2 px-4 rounded-lg font-bold text-sm transition-all ${activeTab === 'tools' ? 'bg-white text-amber-900 shadow-sm' : 'text-amber-700 hover:bg-amber-100'}`}
        >
          גיבוי וכלים
        </button>
      </div>

      {activeTab === 'sync' && (
        <div className="bg-white p-6 rounded-2xl shadow-lg border-2 border-amber-200 animate-fade-in">
          <h3 className="text-xl font-bold text-amber-900 mb-4">חיבור ל-Google Sheets</h3>
          <input 
            type="url" 
            placeholder="https://script.google.com/macros/s/..." 
            className="w-full px-4 py-3 rounded-xl border-2 border-amber-200 mb-4 outline-none font-mono text-xs rtl:ltr"
            value={urlInput}
            onChange={(e) => setUrlInput(e.target.value)}
          />
          <button onClick={handleConnect} className="w-full bg-amber-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-amber-700 shadow-md">חבר לטבלה</button>
        </div>
      )}

      {activeTab === 'deploy' && (
        <div className="space-y-4 animate-fade-in">
          <div className="bg-green-600 text-white p-6 rounded-2xl shadow-lg">
            <h3 className="text-xl font-black mb-2 flex items-center gap-2">
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
              יצרת את המחסן! עכשיו השלב האחרון:
            </h3>
            <p className="text-green-50 text-sm">
              במסך ה-Quick Setup שאתה רואה בגיטהאב, עשה את הפעולות הבאות:
            </p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <div className="bg-white p-5 rounded-xl border-2 border-blue-200 shadow-sm relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-blue-500 text-white px-3 py-1 text-[10px] font-bold">חשוב מאוד!</div>
              <div className="flex items-center gap-3 mb-4">
                <span className="bg-blue-600 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold">1</span>
                <h4 className="font-bold text-slate-900">חפש את הקישור הכחול</h4>
              </div>
              <p className="text-sm text-slate-700">
                חפש בשורה השנייה את הטקסט: <br/>
                <span className="bg-blue-50 text-blue-700 px-2 py-1 rounded font-mono text-xs border border-blue-100">uploading an existing file</span>
              </p>
            </div>

            <div className="bg-white p-5 rounded-xl border-2 border-slate-100 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <span className="bg-slate-900 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold">2</span>
                <h4 className="font-bold text-slate-900">גרירת הקבצים</h4>
              </div>
              <p className="text-xs text-slate-600 mb-2">גרור לתוך הדף את כל הקבצים שרשומים כאן למטה:</p>
              <ul className="text-[10px] grid grid-cols-2 gap-1 font-mono text-slate-500 bg-slate-50 p-2 rounded">
                <li>• App.tsx</li>
                <li>• index.tsx</li>
                <li>• index.html</li>
                <li>• types.ts</li>
                <li>• components/</li>
                <li>• services/</li>
              </ul>
            </div>

            <div className="bg-white p-5 rounded-xl border-2 border-slate-100 shadow-sm">
              <div className="flex items-center gap-3 mb-4">
                <span className="bg-slate-900 text-white w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold">3</span>
                <h4 className="font-bold text-slate-900">שמירה (Commit)</h4>
              </div>
              <p className="text-xs text-slate-600">רד לסוף העמוד בגיטהאב ולחץ על הכפתור הירוק <strong>Commit changes</strong>.</p>
            </div>
          </div>
          
          <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-amber-900 text-xs text-center font-bold">
             אחרי שתסיים, חזור ל-Vercel, עשה רענון, והפרויקט יופיע! 🚀
          </div>
        </div>
      )}

      {activeTab === 'tools' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-fade-in">
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="flex flex-col items-center justify-center p-8 bg-white border-2 border-dashed border-amber-300 rounded-2xl hover:bg-amber-50 transition-all group"
          >
            <span className="font-bold text-amber-900">מיזוג נתונים ממכשיר אחר</span>
            <input type="file" accept=".json" className="hidden" ref={fileInputRef} onChange={(e) => {
               const file = e.target.files?.[0];
               if (file) {
                 const reader = new FileReader();
                 reader.onload = (ev) => {
                   try { onImport(JSON.parse(ev.target?.result as string)); alert('הנתונים מוזגו!'); } catch(e) { alert('קובץ לא תקין'); }
                 };
                 reader.readAsText(file);
               }
            }} />
          </button>
          <button 
            onClick={() => {
              if (complaints.length === 0) return;
              const dataStr = JSON.stringify(complaints, null, 2);
              const dataUri = 'data:application/json;charset=utf-8,'+ encodeURIComponent(dataStr);
              const link = document.createElement('a');
              link.setAttribute('href', dataUri);
              link.setAttribute('download', `Berman_Backup_${new Date().toLocaleDateString('he-IL')}.json`);
              link.click();
            }}
            className="flex flex-col items-center justify-center p-8 bg-amber-600 text-white rounded-2xl shadow-lg hover:bg-amber-700 transition-all group"
          >
            <span className="font-bold text-lg">גיבוי למחשב (JSON)</span>
          </button>
        </div>
      )}
    </div>
  );
};

export default Stats;
