
import React from 'react';

interface HeaderProps {
  setView: (view: 'form' | 'history' | 'stats') => void;
  currentView: string;
}

const Header: React.FC<HeaderProps> = ({ setView, currentView }) => {
  return (
    <header className="bg-white shadow-md border-b border-amber-100">
      <div className="max-w-5xl mx-auto px-4 py-4 flex flex-col md:flex-row items-center justify-between">
        <div className="flex items-center gap-3 mb-4 md:mb-0">
          <div className="bg-amber-600 p-2 rounded-lg">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" />
            </svg>
          </div>
          <div>
            <h1 className="text-2xl font-bold text-amber-900 leading-tight">מאפיית ברמן</h1>
            <p className="text-amber-700 text-sm font-medium">פורטל תלונות מוצרים פנימי</p>
          </div>
        </div>

        <nav className="flex items-center gap-2 bg-amber-50 p-1 rounded-xl">
          <button 
            onClick={() => setView('form')}
            className={`px-6 py-2 rounded-lg transition-all ${currentView === 'form' ? 'bg-amber-600 text-white shadow-md' : 'text-amber-800 hover:bg-amber-100'}`}
          >
            דיווח חדש
          </button>
          <button 
            onClick={() => setView('history')}
            className={`px-6 py-2 rounded-lg transition-all ${currentView === 'history' ? 'bg-amber-600 text-white shadow-md' : 'text-amber-800 hover:bg-amber-100'}`}
          >
            היסטוריה
          </button>
          <button 
            onClick={() => setView('stats')}
            className={`px-6 py-2 rounded-lg transition-all ${currentView === 'stats' ? 'bg-amber-600 text-white shadow-md' : 'text-amber-800 hover:bg-amber-100'}`}
          >
            נתונים
          </button>
        </nav>
      </div>
    </header>
  );
};

export default Header;
