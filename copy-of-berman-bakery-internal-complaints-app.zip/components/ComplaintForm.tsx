
import React, { useState, useRef } from 'react';
import { Complaint, Urgency } from '../types';
import { analyzeComplaint } from '../services/geminiService';

interface ComplaintFormProps {
  onAdd: (complaint: Complaint) => void;
}

const ComplaintForm: React.FC<ComplaintFormProps> = ({ onAdd }) => {
  const [formData, setFormData] = useState({
    productName: '',
    productCode: '',
    description: '',
    targetEmail: '',
    reporterEmail: '',
    image: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submittedComplaint, setSubmittedComplaint] = useState<Complaint | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // יצירת מזהה מכשיר פשוט אם לא קיים
  const getDeviceId = () => {
    let id = localStorage.getItem('berman_device_id');
    if (!id) {
      id = 'DEV-' + Math.random().toString(36).substr(2, 9).toUpperCase();
      localStorage.setItem('berman_device_id', id);
    }
    return id;
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setFormData(prev => ({ ...prev, image: reader.result as string }));
      };
      reader.readAsDataURL(file);
    }
  };

  const generateMailBody = (complaint: Complaint) => {
    return `תלונת מוצר חדשה - מאפיית ברמן
--------------------------
מוצר: ${complaint.productName}
קוד מוצר: ${complaint.productCode}
תאריך: ${complaint.date}
מזהה מכשיר: ${complaint.deviceId}
דווח על ידי: ${complaint.reporterEmail}

תיאור התלונה:
${complaint.description}

ניתוח AI:
קטגוריה: ${complaint.aiAnalysis?.category}
דחיפות: ${complaint.aiAnalysis?.urgency}
סיכום: ${complaint.aiAnalysis?.summary}

*נשלח דרך פורטל התלונות הפנימי*`;
  };

  const sendWhatsApp = () => {
    if (!submittedComplaint) return;
    const text = generateMailBody(submittedComplaint);
    const url = `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank');
  };

  const sendEmail = () => {
    if (!submittedComplaint) return;
    const body = generateMailBody(submittedComplaint);
    const subject = `תלונה על מוצר: ${submittedComplaint.productName}`;
    const mailtoUrl = `mailto:${submittedComplaint.targetEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoUrl;
  };

  const copyText = () => {
    if (!submittedComplaint) return;
    const text = generateMailBody(submittedComplaint);
    navigator.clipboard.writeText(text);
    alert('הדיווח הועתק! ניתן להדביק אותו בכל מקום.');
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (isSubmitting) return;
    setIsSubmitting(true);

    try {
      const analysis = await analyzeComplaint(formData.description, formData.productName, formData.image);
      const newComplaint: Complaint = {
        id: Date.now().toString() + '-' + Math.random().toString(36).substr(2, 5),
        ...formData,
        date: new Date().toLocaleDateString('he-IL'),
        status: 'נשלח',
        deviceId: getDeviceId(),
        aiAnalysis: analysis
      };

      onAdd(newComplaint);
      setSubmittedComplaint(newComplaint);
    } catch (error) {
      console.error(error);
      const fallbackComplaint: Complaint = {
        id: Date.now().toString(),
        ...formData,
        date: new Date().toLocaleDateString('he-IL'),
        status: 'נשלח',
        deviceId: getDeviceId()
      };
      onAdd(fallbackComplaint);
      setSubmittedComplaint(fallbackComplaint);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submittedComplaint) {
    return (
      <div className="bg-white rounded-3xl shadow-2xl p-8 border border-amber-100 animate-fade-in max-w-xl mx-auto text-center">
        <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
          <svg className="w-12 h-12" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7" /></svg>
        </div>
        
        <h2 className="text-3xl font-black text-amber-900 mb-2">התלונה נרשמה!</h2>
        <p className="text-amber-700 mb-8 font-medium">הנתונים נשמרו במערכת. בחר איך לשלוח את העותק למנהל:</p>
        
        <div className="space-y-4">
          <button onClick={sendWhatsApp} className="w-full flex items-center justify-center gap-3 bg-[#25D366] text-white py-4 rounded-2xl font-bold text-lg shadow-lg hover:opacity-90 transition-all">
            שלח בוואטסאפ (מומלץ)
          </button>
          <button onClick={sendEmail} className="w-full flex items-center justify-center gap-3 bg-amber-600 text-white py-4 rounded-2xl font-bold text-lg shadow-lg hover:bg-amber-700 transition-all">
            שלח במייל
          </button>
          <button onClick={copyText} className="w-full py-3 border-2 border-amber-200 rounded-xl font-bold text-amber-800 hover:bg-amber-50 transition-all">
            העתק טקסט ללוח
          </button>
        </div>

        <button 
          onClick={() => {
            setSubmittedComplaint(null);
            setFormData({ productName: '', productCode: '', description: '', targetEmail: '', reporterEmail: '', image: '' });
          }}
          className="mt-10 text-amber-600 font-bold hover:underline"
        >
          + דיווח על תלונה חדשה
        </button>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-amber-100 max-w-4xl mx-auto">
      <div className="p-8">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold text-amber-900 mb-2">שם המוצר</label>
              <input required type="text" placeholder="שם הלחם / מוצר" className="w-full px-4 py-3 rounded-lg border border-amber-200 focus:ring-2 focus:ring-amber-500 outline-none" value={formData.productName} onChange={e => setFormData({...formData, productName: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-bold text-amber-900 mb-2">קוד מוצר (אם יש)</label>
              <input type="text" placeholder="קוד מוצר" className="w-full px-4 py-3 rounded-lg border border-amber-200 focus:ring-2 focus:ring-amber-500 outline-none" value={formData.productCode} onChange={e => setFormData({...formData, productCode: e.target.value})} />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-bold text-amber-900 mb-2">המייל שלך</label>
              <input required type="email" placeholder="עובד@berman.co.il" className="w-full px-4 py-3 rounded-lg border border-amber-200 focus:ring-2 focus:ring-amber-500 outline-none" value={formData.reporterEmail} onChange={e => setFormData({...formData, reporterEmail: e.target.value})} />
            </div>
            <div>
              <label className="block text-sm font-bold text-amber-900 mb-2">מייל המנהל לקבלת התלונה</label>
              <input required type="email" placeholder="quality@berman.co.il" className="w-full px-4 py-3 rounded-lg border border-amber-200 focus:ring-2 focus:ring-amber-500 outline-none" value={formData.targetEmail} onChange={e => setFormData({...formData, targetEmail: e.target.value})} />
            </div>
          </div>

          <div>
            <label className="block text-sm font-bold text-amber-900 mb-2">תיאור הבעיה</label>
            <textarea required rows={4} placeholder="מה קרה במוצר? (עובש, אריזה, משקל וכו')" className="w-full px-4 py-3 rounded-lg border border-amber-200 focus:ring-2 focus:ring-amber-500 outline-none resize-none" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
          </div>

          <div>
            <label className="block text-sm font-bold text-amber-900 mb-2">הוסף צילום</label>
            <div className="flex flex-col items-center justify-center border-2 border-dashed border-amber-200 rounded-xl p-6 bg-amber-50/30 hover:bg-amber-50 cursor-pointer" onClick={() => !formData.image && fileInputRef.current?.click()}>
              {!formData.image ? (
                <div className="text-center">
                  <svg className="mx-auto h-12 w-12 text-amber-400 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                  <span className="text-amber-800 font-bold">צלם את המוצר</span>
                </div>
              ) : (
                <div className="relative w-full max-w-xs">
                  <img src={formData.image} alt="תצוגה" className="rounded-lg shadow-md w-full" />
                  <button type="button" onClick={(e) => { e.stopPropagation(); setFormData({...formData, image: ''}); }} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-lg">
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
                  </button>
                </div>
              )}
              <input type="file" accept="image/*" capture="environment" className="hidden" ref={fileInputRef} onChange={handleImageChange} />
            </div>
          </div>

          <button 
            type="submit" 
            disabled={isSubmitting} 
            className={`w-full py-4 rounded-xl font-bold text-xl text-white shadow-lg transition-all ${isSubmitting ? 'bg-amber-400' : 'bg-amber-600 hover:bg-amber-700'}`}
          >
            {isSubmitting ? 'מעבד נתונים...' : 'שמור תלונה והמשך לשליחה'}
          </button>
        </form>
      </div>
    </div>
  );
};

export default ComplaintForm;
